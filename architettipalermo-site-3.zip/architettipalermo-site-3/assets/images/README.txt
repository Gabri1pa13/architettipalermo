Metti qui le foto di Studio4E.

- Rinomina una foto principale in: hero.jpg (consigliato 1600x900 o superiore)
- Aggiungi eventuali altre immagini: project-1.jpg, project-2.jpg, ecc.

Il sito è già pronto per GitHub Pages.
